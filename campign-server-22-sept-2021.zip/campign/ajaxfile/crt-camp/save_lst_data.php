<?php


require("../../confige/camp_confige.php");




$merg_fld=$_POST['merge_fld'];

$list_dt=$_POST['list_data'];

$filt_dt=$_POST['filt_opt'];


$con_id_dt=$_POST['con_id'];


function hit_query_php($conn,$sql){


if ($conn->query($sql) === TRUE) {
  return 1;
} else {
  return 0;
}



}


$flg_suc=1;

$del_old_lst="delete from camp_contact_tbl where camp_con_id='".$con_id_dt."'";

$res_del=hit_query_php($camp_name_conn,$del_old_lst);

$list_dt=json_decode($list_dt);


$con_id_dt=trim($con_id_dt);

foreach ($list_dt as $key => $value) {
	$isrt_in_con_tbl="insert into camp_contact_tbl values('$con_id_dt','$value','$filt_dt','$merg_fld','2')";
	$res_of_qur= hit_query_php($camp_name_conn,$isrt_in_con_tbl);

	if($res_of_qur==0){
$flg_suc=0;

	}
}

echo $flg_suc;

?>
