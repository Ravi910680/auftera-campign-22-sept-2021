<?php

require("../../confige/save_url_db_confige.php");




function getValidUrlsFrompage($html)
  {
    $links_ret =array();
   
//Create a new DOM document
$dom = new DOMDocument;

//Parse the HTML. The @ is used to suppress any parsing errors
//that will be thrown if the $html string isn't valid XHTML.
@$dom->loadHTML($html);

//Get all links. You could also use any other tag name here,
//like 'img' or 'table', to extract other tags.
$links = $dom->getElementsByTagName('a');

//Iterate over the extracted links and display their URLs
foreach ($links as $link){
    //Extract and show the "href" attribute.
   
$url_dt=$link->getAttribute('href');



if (filter_var($url_dt, FILTER_VALIDATE_URL) !=FALSE) {

    array_push($links_ret,$url_dt );

}


}

    return $links_ret;
  

}


function getInbetweenStrings($start, $end, $str){
    $matches = array();
    $regex = "/$start([a-zA-Z0-9_]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[1];
}


function isrt_url_data_in_db($conn,$url_id,$url){



$isrt_query_db="insert into temp_url_data_crw value('$url_id','$url')";

if ($conn->query($isrt_query_db) === TRUE) {
 


 return 1;

}

return 0;

}


function url_get_contents ($Url) {
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

$camp_name=$_POST['camp_id'];




$camp_temp_name=$_POST['temp_id'];

$camp_name=trim($camp_name);


$camp_save_dt_name=$camp_name."#".$camp_temp_name.".php";



$html = url_get_contents("https://template.auftera.com/template/crt-template/crtedtemp/".$camp_temp_name.".html");


$links = getValidUrlsFrompage($html);


 $flg_of_num_hr=10;

 $var_of_suc_url=10;


foreach ($links as $key => $value) {
	


$create_red_url="href=\"http://track-email.auftera.com/email/click/<?php echo \$_GET['con_id'];?>/<?php echo \$_GET['lst_name'];?>/".$camp_name."/".$flg_of_num_hr."\"";

$value_isrt=$value;

$value="href=\"".$value."\"";

$html=str_replace($value,$create_red_url,$html);




$var_of_suc_url+=isrt_url_data_in_db($url_temp_camp_conn ,$camp_name."@".$flg_of_num_hr,$value_isrt);

$flg_of_num_hr+=1;

}


echo $html;



$str_arr = getInbetweenStrings(':', ':', $html);


$str_arr=array_unique($str_arr);

foreach ($str_arr as $key => $value) {
    

$html=str_replace(":".$value.":","<?php echo \$_GET['".$value."'];?>",$html);


}



echo $camp_save_dt_name;
$myfile = fopen("../../camp_temp/".$camp_save_dt_name, "w") or die("Unable to open file!");
$txt = $html;

$open_res_img_tag="<img src='http://track-email.auftera.com/email/open/<?php echo \$_GET['con_id'];?>/<?php echo \$_GET['lst_name'];?>/".$camp_name."'>";
fwrite($myfile, $open_res_img_tag);

fwrite($myfile, $txt);
fclose($myfile);











echo 1;












?>
