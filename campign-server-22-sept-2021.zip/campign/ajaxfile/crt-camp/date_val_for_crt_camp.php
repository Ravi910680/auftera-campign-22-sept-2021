<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
$id=$_SESSION['id'];


$get_tz_usr=file_get_contents("https://account.auftera.com/account/main/settings/ajaxfile/get_tz_of_usr.php?id=".$id);



$tz=json_decode($get_tz_usr)[0]->time_zone;



$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);



$input = $_POST['ip_for_time_sel_camp']; 


$date = strtotime($input); 
$sel_time_for_camp= date('Y-m-d H:i:s', $date);


$sel_time_obj=strtotime($sel_time_for_camp);


if($sel_time_obj>$late_time){

	echo 1;
}else{

	echo 0;
}

?>
