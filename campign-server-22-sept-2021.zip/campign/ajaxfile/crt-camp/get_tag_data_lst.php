<?php
session_start();


require("../../confige/manage_tag.php");


$id=$_SESSION['id'];


$arr_of_dt=array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {





    $loc_arr=array();


$file_name_dec=$row['tag'];

$loc_arr['label']=$file_name_dec;
$loc_arr['value']=$row['id'];

 
array_push($arr_of_dt, $loc_arr);


  }

  echo json_encode($arr_of_dt);

?>
