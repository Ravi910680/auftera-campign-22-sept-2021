<?php

session_start();

require("../../confige/camp_confige.php");




$id=$_SESSION['id'];

$response_camp_data=array();

$camp_id=$_POST['camp_id'];


$camp_id=$id."^".$camp_id;

$sel_camp_dt_query="select * from camp_name_tbl where camp_name='$camp_id'";





$result = $camp_name_conn->query($sel_camp_dt_query);



while($row = $result->fetch_assoc()) {
    


$camp_main_id=$row['camp_contact_id'];

$camp_shed_time=$row['camp_shed_time'];



  }


$response_camp_data['camp_con_id']=$camp_main_id;

$response_camp_data['shed_time']=$camp_shed_time;

$sel_query_for_lst_data="select * from camp_contact_tbl where camp_con_id='$camp_main_id'";



$result = $camp_name_conn->query($sel_query_for_lst_data);

$list_con=array();

while($row = $result->fetch_assoc()) {
    

array_push($list_con, $row['list_id']);

$response_camp_data['merge_fld']=$row['merge_fld'];


$response_camp_data['filt_data']=$row['filt_data'];

  }



$response_camp_data['con_list']=$list_con;


$sel_con_query="select * from camp_content_tbl where camp_id='$camp_main_id'";

$result = $camp_name_conn->query($sel_con_query);



while($row = $result->fetch_assoc()) {
    

$response_camp_data['content_db']=$row;


  }

print_r(json_encode($response_camp_data));

?>