<?php
session_start();
require("../../confige/template_confige.php");

$id=$_SESSION['id'];

$url_temp=$_POST['temp_url'];

$camp_id=$_POST['camp_id'];

$camp_crt_id=$id."^".base64_encode(explode("^",$camp_id)[1]);

$html = file_get_contents($url_temp);

$date=date("Y-m-d");

$myfile = fopen("../../../template/crt-template/crtedtemp/".$camp_crt_id.".html", "w") or die("Unable to open file!");

fwrite($myfile, $html);


$sql = "INSERT INTO temp_details (id, tempname, date) VALUES ('$id', '$camp_crt_id', '$date')";



if($template->query($sql)==true){

$flg_suc_temp=1;

}


echo $camp_crt_id;

?>