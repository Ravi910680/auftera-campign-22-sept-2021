<?php
session_start();



require("../../confige/camp_confige.php");


$id=$_SESSION['id'];


function get_curr_time(){


$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);

return $late_time;



}




$camp_name=$_POST['camp_name'];


$old_name=$_POST['old_name'];




$camp_name=$id."^".$camp_name;





if($old_name=="new campigns "){


$camp_con_id=$id."^".get_curr_time();



$isrt_camp_name="insert into camp_name_tbl VALUES ('$id','$camp_name','$camp_con_id','$camp_con_id','','3')";


}else{

	$old_name=$id."^".$old_name;

$camp_con_id=1;

$isrt_camp_name="update camp_name_tbl set camp_name='$camp_name' where camp_name='$old_name'";


}

if ($camp_name_conn->query($isrt_camp_name) === TRUE) {
      


	echo $camp_con_id;



} else {
  echo 0;
}

?>
