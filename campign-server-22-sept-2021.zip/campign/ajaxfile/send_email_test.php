<?php

require '../ab_testing/ajaxfile/lib_auftera.php';
session_start();

$email=$_SESSION['email'];

$temp_id=$_POST['temp_id'];
$sub_txt=$_POST['sub_mail'];

$send_arr_body=array (
  'to-name' => 'admin',
'from' =>'ravigorasiya65@gmail.com',  
  'from-name' => 'auftera',
  'subject' => $sub_txt,
  'content' => $temp_id,
  'tp_dir' => 'direct',
   
);


echo auft_req_api('POST','send/497889959^dXNlcl9saXN0/template/'.$email.'/',$send_arr_body,'f402he2g0gh1j0jl3idih04g');
?>
