<?php
session_start();
require("../../confige/camp_confige.php");

require("../../confige/social_post_confige.php");



$res_data=array();

$id=$_SESSION['id'];


function get_fb_camp($conn,$id){


$sel_query='select * from camp_soc_hy where id="'.$id.'"';

$loc_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
    array_push($loc_arr, $row);

  }
} else {
  
}


return $loc_arr;


}


function conv_utc_to_loc($date,$tz){


	$given = new DateTime($date, new DateTimeZone("UTC"));
$given->setTimezone(new DateTimeZone($tz));
$output = $given->format("Y-m-d H:i:s");

return $output;

}


function get_mail_camp($conn,$id){

$get_tz_usr=file_get_contents("https://account.auftera.com/account/main/settings/ajaxfile/get_tz_of_usr.php?id=".$id);



$tz=json_decode($get_tz_usr)[0]->time_zone;


$sel_query='select * from camp_name_tbl where id="'.$id.'" ORDER BY camp_shed_time DESC';

$loc_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


$row["camp_shed_time"]=conv_utc_to_loc($row["camp_shed_time"],$tz);	  
    array_push($loc_arr, $row);

  }
} else {
 
}


return $loc_arr;


}


$res_data['email_camp']=get_mail_camp($camp_name_conn,$id);

$res_data['soc_camp']=get_fb_camp($social_post_conn,$id);


print_r(json_encode($res_data));


?>
