<?php


$servername = "campign.chmwcgvoxwwi.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="camp_email_db";




$camp_name_conn = mysqli_connect($servername, $username, $password,$db);




?>

