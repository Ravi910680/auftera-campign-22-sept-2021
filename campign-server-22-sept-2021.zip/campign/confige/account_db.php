<?php


$servername = "database-1.c1xleyzjkk8s.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="signup";




$conn_acc= mysqli_connect($servername, $username, $password,$db);




?>

