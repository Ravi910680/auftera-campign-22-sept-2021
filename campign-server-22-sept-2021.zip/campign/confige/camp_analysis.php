<?php


$servername = "database-1.cnaxgy5vyqbq.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="camp_analysis";




$camp_ana_conn= mysqli_connect($servername, $username, $password,$db);




?>

