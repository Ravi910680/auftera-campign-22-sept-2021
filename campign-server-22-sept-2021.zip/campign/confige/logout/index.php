<?php
session_start();




session_destroy();

$req_page=$_GET['next_act_serv'];


$url="https://".$req_page.".auftera.com/".$req_page."/confige/logout/?next_act_serv=studio";
header("Location: ".$url);
?>
