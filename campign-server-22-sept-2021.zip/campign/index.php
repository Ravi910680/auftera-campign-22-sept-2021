
<?php
session_start();

require("./confige/camp_confige.php");

$mail=$_SESSION['email'];

$id=$_SESSION['id'];



if(isset($_GET['camp_id'])){
$get_camp_id=$_GET['camp_id'];

$sel_data_temp_ver="select * from camp_name_tbl where camp_name='".$get_camp_id."'";

$res=$camp_name_conn->query($sel_data_temp_ver);

if($res->num_rows > 0){

while($row = $res->fetch_assoc()) {

if($row['flg_send']=='2'){
  header("Location: ./pages/crt_camp_exist/?camp_id=".$get_camp_id);

}
   
  }

}else{


header("Location: ./pages/camp_not_fd/");


}




$get_camp_id=explode("^", $get_camp_id)[1];

}else{
  $get_camp_id="new campigns";
}


?>






<html><head>




<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">




<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.tooltip-arrow {
    
    }


[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
    margin-right: auto;
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
    margin-right: auto;
    margin-left: 20px;
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    justify-content: center;
    flex-direction: column;
    display: flex;
    margin: auto;
    font-family: 'Lato';
    }
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}
















.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}

.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 12px;
    }


    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }
















body{
  font-family: 'IBM Plex Sans', sans-serif;
letter-spacing:0.2px;
}

  .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
  border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
        width: 92%;
    margin-left: 8%;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

  align-items: 'center';
       
  border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }




.con_of_sel_data{

height: 100px;

}


.con_of_sel_data_seg{
margin-top: 40px;
display: none;
}

.ip_of_sel_opt{

  margin: 10px;
}

.sel_des_of_opt{

  height: 44px;
    border: 1px solid rgba(0, 0, 0, 0.15);
    border-radius: 5px;
    padding: 5px 10px;
}


.step {
    width: 50%;
    margin: auto;
height: 82vh;
    overflow: scroll;
  }


  .step::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.step {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

.camp_name_of_crt {
    font-weight: 500;
    font-size: 3vh;
    padding: 3vh;
    color: #4a154bd9;
    display: inline-flex;

  }

  div#name_hld_crt {
    font-size: 23px;
    color: black;
    font-weight: 300;
}

div#clc_on_edt_crt {
    padding: 5px;
    margin-top: 4.5px;
    background: #f2f2f2;
    border-radius: 5px;
    margin-left: 10px;
    box-shadow: rgb(0 0 0 / 12%) 0px 1px 3px, rgb(0 0 0 / 24%) 0px 1px 2px;
    }
    img.ico-dsg-shd {
    height: 19.5px;
}
.simplepicker-day-header {
    color: #fff;
    background-color: #016565;
    text-align: center;
    padding: 4px 0;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }

  .simpilepicker-date-picker {
    width: 326px;
    cursor: auto;
    font-family: Verdana,Geneva,Tahoma,sans-serif;
    font-size: 14px;
    background-color: #fff;
    margin: 5% auto;
    box-shadow: 1px 2px 4px 0.5px rgba(0,0,0,.22), 1px 2px 4px 0.5px transparent;
    border-radius: 10px;

  }

#clc_on_edt_crt:hover{

box-shadow: none;
cursor: pointer;

}




















.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}




</style>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

  <style>




body{
  font-family: 'lato';
letter-spacing:0.2px;
}


.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

  .dropdown-menu{
    border-radius:0px !important;
    box-shadow:none !important;
    
    border:1px solid #dedddc !important;
    
}

.nav-link:hover{
    cursor:pointer;
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.main-content {
    position: relative;
    top: 8vh;
}

a{
    font-weight:600;
}
  .navbar-light .navbar-brand {
    color: white;

  }


  .navbar-light .navbar-brand:hover, .navbar-light .navbar-brand:focus {
    color: white;

  }
  .navbar {
    background: #4a154bd9;
}



.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size:0.9rem !important;
    font-weight: 600;


}

.dropdown-menu.show {
    border-radius: 10px !important;

}



.navbar-light .navbar-nav .nav-link:hover, .navbar-light .navbar-nav .nav-link:focus {
    color: white;

}


.navbar-light .navbar-nav .show>.nav-link, .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .nav-link.active {
    color: white;
}
.modal{

background: #00000070;

}

h2{

font-size: 14px;
}






.progressbar {
      counter-reset: step;
  }
  .progressbar li {
    font-weight: 600;
      list-style-type: none;
      width: 25%;
      float: left;
      font-size: 12px;
      position: relative;
      text-align: center;
      text-transform: uppercase;
      color: #7d7d7d;
  }
  .progressbar li:before {
      width: 30px;
      height: 30px;
      content: counter(step);
      counter-increment: step;
      line-height: 30px;
      border: 2px solid #7d7d7d;
      display: block;
      text-align: center;
      margin: 0 auto 10px auto;
      border-radius: 50%;
      background-color: white;
  }
  .progressbar li:after {
      width: 100%;
      height: 2px;
      content: '';
      position: absolute;
      background-color: #7d7d7d;
      top: 15px;
      left: -50%;
      z-index: -1;
  }
  .progressbar li:first-child:after {
      content: none;
  }
  .progressbar li.active {
      color: #0092ff;
      font-weight: 600;
  }
  .progressbar li.active:before {

      border-color: #0092ff;
      background-color: #0092ff;
  }
  .progressbar li.active + li:after {
      background-color: #0092ff;
  }


.full-camp-content {
    width: 100%;
    height: 10vh;
border-bottom: 1px solid #ebeaeb;

  }

  .con-of-step-data {
    width: 400px;
    float: right;

  }

.camp_name_of_crt{
width: 50%;

}
.con-of-step-data{
  width: 50%;
}

.base_con_of_step {
    width: 400px;
    float: right;
  }

  .multi_sel_label{
    margin: 10px;
  }
.singel_sel_label{
  margin:10px 0px ;
}
  .label_desg{

font-weight: 600;
color: #3c4858;

  }


  input.ip_fld_desg {
    height: 44px;
    border: 1px solid rgba(0, 0, 0, 0.15);
    border-radius: 4px;
    padding: 0px 10px;

  }

  p{
    margin-bottom: 0px;
      }


      .val_crt_ip_desg{

        font-weight: 500;
    font-size: 3vh;
    
    color: #4a154bd9;
      }

.sty_para_tag{
  color: #687484;
    font-size: 0.875rem;
    font-family: Roboto,sans-serif;
   

}



p.bel_ip_txt {
    color: #687484;
    font-size: 0.875rem;
    font-family: Roboto,sans-serif;
    padding: 10px 0px;

    }


.err_desg_of_camp{
 color: red;
    font-size: 0.875rem;
    font-family: Roboto,sans-serif;
    padding: 10px 0px;

}
    .mid_con {
    width: 50%;
    padding: 3vh;
    height: 76vh;
    overflow: scroll;
  }


.mid_con::-webkit-scrollbar {
  display: none;
}
.mid_con {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

  .head_req_con {
    width: 22%;
    height: min-content;
    margin-top: 20px;
    padding: 20px;
    box-shadow: rgb(0 0 0 / 5%) 0px 1px 2px 0px;
    background: white;
    border-radius: 10px;
  }

  .head_req_con h2{
    font-weight: 400;
    font-size: 15px;
color: #241c15;
    line-height: 1.25;

  }

  p.para_txt_for_info {
    border-bottom: 1px solid #dedddc;
    padding-bottom: 20px;
    padding-top: 20px;
color: rgba(36,28,21,0.65);
    font-weight: 400;
    
    font-size: 12px;

  }

.ip_fld_desg:focus{

border: 2px solid blue;

}

.img-mob-appl{

  width: 100%;
    border: solid 1px #dedddc;
    border-radius: 4px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.meth_sel_temp {
    padding: 40px 0px 10px 0px;
    border-bottom: 1px solid #c0ccda;
    height: auto;

  }



span.span-sel-temp-method {
    padding: 10px;
    color: #3c4858;
    font-size: 87.5% !important;
    font-weight: 400;
    padding-bottom: 10px;
    font-weight: 500;

  }

.span-sel-temp-method:hover{
cursor: pointer;

}
  .act-span-sel{
color: #0092FF !important;
    border-bottom: 2px solid;

}

.main-con-of-sel-con {
    padding: 40px 0px;

    }

    .card {
      border: 1px solid rgb(0 0 0 / 29%);
    text-align: center;
    padding: 20px;
    margin: auto;
    width: 17rem !important;
}

.card:hover{
border-radius:4px; 
border: 1px solid #0092FF;
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.2), inset 0 0 0 2px #0092FF;
  cursor: pointer;
}


.temp_con:hover{

  border-radius:4px; 
border: 1px solid #0092FF;
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.2), inset 0 0 0 2px #0092FF;
  cursor: pointer;
}

.temp_con_active{

 border-radius:4px; 
border: 1px solid #0092FF !important;
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.2), inset 0 0 0 2px #0092FF;
  cursor: pointer;

}

.modal-dialog.modal-dialog-centered {

min-width: 70%;
}

.modal-body {
    height: 60vh;
}

.note-editor.note-frame .note-status-output{
  display: none;
}

.note-editable{
  height: 40vh !important;
}

.txt_are_desg{

  width: 100%;

  height: 50vh;
}


.temp_con{
    padding:20px;width:fit-content;border-radius:5px;border:1px solid #f2f2f2;
    margin-bottom:20px;
background:white;
    
}
.temp_con:hover{
    cursor:pointer;
    opacity:0.8;
}

.temp_name_sty{
padding-top: 20px;
width:180px;;
    color: #341161;
    font-family: 'Nunito Sans','Avenir Next','Segoe UI','Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 17px;
    font-weight: 540;
    letter-spacing: 0.8px;
}


.main_rew_con {
    padding: 10px;
    margin: 2%;

  }
.reviw-con{
  
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 20px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;



  }


.main-con h4 {
    font-size: 0.9375rem;
    margin-top: 1rem;
}

.h5, h5 {
    font-size: 0.8125rem;
    }
  .rew-head-con {
    padding: 10px;
    border-bottom: 1px solid #c0ccda;

  }
.main-con{
  padding: 30px;
}

span.ret_edit_step {
    float: right;
    color: #0092ff;
    font-size: 87.5%!important;
    padding: 2px;
    font-weight: 500;

    }

    span.rew-opt-con-css {
    font-weight: 700;
    color: #3c4858;

  }


  .badge:hover{
cursor:pointer;
}

.badge-dark-active{
background:#4a154bd9 !important;
color:white !important;


}

h4{
  margin-top: 1rem;
}

.row{
  margin: 0px;
}

.main-con-of-img-pre{

text-align: center;
}

.sel_time_btn_con {
    width: 50%;
    text-align: center;
    margin: auto;

    }

    div#held_ver_data_of_camp {
    padding: 10px 0px;
    font-weight: 500;
    color: green;

  }

.save_camp_lst-step{
  text-align: right;
  padding: 20px;
}

.bottom-btn:hover{
  cursor: pointer;
}

.ret_edit_step:hover{
cursor: pointer;
}





.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

















#next_temp_btn{
  cursor: pointer;
}

















button.btn-theme-dsg {
  font-family 'IBM Plex Sans', sans-serif !important: 
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;


  }

button.btn_hover_clr {
  font-family 'IBM Plex Sans', sans-serif !important: 
    margin-top: 10px;
    background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    font-size: 13px;
    font-weight: 500;
   
    color: #471f48f0;

  }

  button.btn_hover_clr:hover {
    background: #b284b336;
    cursor: pointer;

  }

  .modal{
    z-index: 10000000000;
  }


  .ip-by-def-dsg {
    font-family 'IBM Plex Sans', sans-serif !important;
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.card{
  width: 30% !important;
}







.head-of-txt-info{
text-transform: uppercase;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif;
text-align: center;

}


body{


font-family: 'IBM Plex Sans', sans-serif;

}

.vert-cent-div {
  width: min-content;
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.info-err-img{
  height: 200px;
}

.dt-knw-abt-camp{
  font-weight: 600;
  font-size: 13px;
  padding-top: 10px;
  text-align: center;
}

.txt-hlght-in-para{
  color: green;
}




.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.all-ab-tst-res-con-main {
   

  }
  tr {
    border-bottom: 1px solid #f2f2f2;
  }
  td.tbl-column-ab_test {
    width: 30%;
    font-size: 13px;
  }


.card-2 {
    min-width: 100%;
    padding: 0px;
    border-radius: 0px;
    border: none !important;
    box-shadow: none !important;

  }

  div#collapseOne {
    border: 2px solid #0092FF;
    border-radius: 10px;
    box-shadow: none;

  }

.head-of-ab-tst-tru {
    padding: 15px;
    color: white;
    background: #6bb179;
    border-radius: 10px;
    font-weight: 600;
    font-size: 15px;
  }
  .imprt-of-its {
    padding: 20px 0px;
    text-align: left;
  }

  table.ab-test-data {
    width: 100%;

  }

  table.ab-test-data {
    width: 100%;
  }

  .solv_con-of-fact {
    font-size: 13px;
    font-weight: 400;
    padding: 30px 0px;
  }

  .not-fd-temp-in-acc {
    width: 500px;
    margin: auto;
    text-align: center;
  }

  span.temp-not-fd-txt {
    color: #807a7a;
    font-weight: 500;
    font-size: 13px;

  }


.auta-main-dis-dash {
    width: 240px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 300px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
}

.main-con-img-temp {
    flex: auto;
    min-height: 216px;
    display: inline-grid;
    width: 100%;
    background-size: cover;
    border-radius: 5px;
    }

.step{
    height: calc(82vh - 52px);
}

.bottom-nav-of-camp-btn {
    padding: 10px;
    text-align: right;
    border-top: 1px solid #f2f2f2;
    background: white;
    }

    .edt_of_ip_fld{
        margin: 0px;
    height: 31px;
    max-width: 200px;
    }


.reviw-con{

background: white;

}




div#accordion {
    overflow: scroll;
    padding-bottom: 1rem;
}

.btn.btn-link.collapsed {
    width: 100%;
    border-radius: 10px;
    background: white;
    margin-bottom: 10px;

}

.card-header{

border-bottom:0px;
background:none;


}


.per_def_tst_rat {
    padding: 20px;
    text-align: center;
}

.spn-of-tst-ovr {
    width: fit-content;
    margin: auto;
    padding: 4px 40px;
    border-radius: 50px;
    box-shadow: rgb(0 0 0 / 12%) 0px 1px 3px, rgb(0 0 0 / 24%) 0px 1px 2px;
}

span.per_def_of_test {
    font-size: 50px;
    color: #0e860e;
    font-weight: 700;
}

span.out-of-tst {
    color: black;
    font-size: 20px;
    font-weight: 300;
}

.modal-body{

overflow: scroll;


}

.ext-res-opn-mdl{

font-size: 12px;
    margin-left: 10px;
    border-bottom: 1px solid;
    color: black;
    font-weight: 500;
    display: inline-block;

}

.ext-res-opn-mdl:hover{

cursor:pointer;

}


.tooltip-inner{
font-family: 'Lato';
}
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link rel="stylesheet" href="time/simplepicker.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
<script src="time/simplepicker.js"></script>
<script type="text/javascript" src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968350/dashboard-js/bundel.min_ymfzxb.js"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">

     <?php    require("./confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx">
        
 <?php    require("./confige/header/header-new.php");?>
     


       
    
 <div class="main-auta-con" id='main-loader-containre'>    


<div class="vert-cent-div err-menu-cls-dsg" id='err_msg_dt_trg'>

 
 <span id='con-of-err-msg'>
error to create campign

</span>

<span class="cls-err-menu" id='cncl-err-msg'>

<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>

</span>


</div>

<div class="full-camp-content row" style="top:8vh;height:10vh;">












<div class="camp_name_of_crt" id="name_hld_crt" ><div class="con-of-camp-name" >new campigns</div><div class="con-of-edt-name" id="clc_on_edt_crt"> <img src="https://res.cloudinary.com/heptera/image/upload/v1628333996/campign/create_black_24dp_twq8d8.svg" class="ico-dsg-shd"> </div></div>








<div class="con-of-step-data">

<div class="base_con_of_step">
<div class="container">
      <ul class="progressbar">
          <li  id="step-1-desg"  data-step="step_1" class="dir_stp active"></li>
          <li id="step-2-desg" data-step="step_2"></li>
          <li id="step-3-desg" data-step="step_3"></li>
          <li id="step-4-desg" data-step="step_4"></li>
  </ul>

</div>
</div>
</div>
</div>

<div class="con-of-crt-camp-data">


<div class="step" id="step_1" style="display:block" >

<div class="con_of_sel_data">

<label class="multi_sel_label label_desg">Select Audiance</label><br>
<span class="autocomplete-select"></span>

</div>


<span class="err_desg_of_camp" id="dt_of_sel_aud_err" style="
    margin: 10px;
"></span>


<div class="ip_of_sel_opt" >
<label class="singel_sel_label label_desg">Filter Audiance</label><br>
<select class="sel_des_of_opt" id="sel_opt_tp_chg">
 <optgroup label="All Subscriber">  <option value="all_sub">All Subscriber</option></optgroup>


  <optgroup label="For Tag">
  <option value="tag">tag</option></optgroup>


  <optgroup label="For Segment">  <option value="segment">Segment</option></optgroup>

  <optgroup label="Pre Built Segment">  

    <option value="new_sub">New Subscriber</option>
     <option value="act_sub">Active Subscriber</option>
      <option value="inact_sub">Inactive Subscriber</option>



  </optgroup>
 
</select>



</div>

 <div class="con_of_sel_data_seg" >
<label class="multi_sel_label label_desg">Select Field</label><br>
<span class="autocomplete-select-seg"></span></div>



<div class="ip_of_sel_opt sel_merg_fld" style="padding: 40px 0px;">

<label class="singel_sel_label label_desg">Merge Field</label><br>

<p class="bel_ip_txt" >Add merge tags to display your recipient's name to make it more personal and help avoid spam filters. For example, *|FNAME|* *|LNAME|* will show as "To: Bob Smith" instead of "To: bob@example.com."</p><br>

<p class="bel_ip_txt" style="font-weight:600;">If not find Field in list than email is by default.</p><br>
<input type="text" class="ip-by-def-dsg ip_of_merg_fld">

</div>




</div>




<div class="step row" id="step_2" style="width:100%;display:none" >
<div class="head_req_con" style="margin-left:3%">

<h2>Best for Subject Line.</h2>

<p class="para_txt_for_info">Try to use no more than 9 words</p>
<p class="para_txt_for_info">Avoid using more than 60 characters</p>

<p class="para_txt_for_info">Try to use no more than 1 emoji</p>

<p class="para_txt_for_info" style="border-bottom:none;">Avoid using more than 3 punctuation marks</p>

<img class="img-mob-appl" src="https://res.cloudinary.com/heptera/image/upload/v1596694486/IMG_20200806_113502_vttdct.jpg" style="
    width: 100%;
">

</div>


<div class="mid_con">
<label class="singel_sel_label label_desg">Subject Line</label><br>

<input type="text" class="ip-by-def-dsg" id="sub_ip_fld" style="width:100%" >

<span class="err_desg_of_camp" id="dt_of_ent_mail_sub_err" style="
"></span>

<p class="bel_ip_txt">Write a subject line that clearly describes your email content. It will be visible in your recipient's inbox and is the first content they will see. For example: 'Private sale: 25% off our new collection</p>

<label class="singel_sel_label label_desg">Preview text</label><br>

<input type="text" class="ip-by-def-dsg" id="pre_ip_fld" style="width:100%" >

<span class="err_desg_of_camp" id="dt_of_ent_mail_pre_err" style="
"></span>

<p class="bel_ip_txt">Write a short text (about 35 characters) that gives an overview of the content of your email. This will significantly increase your opening rate. This feature is supported by most email clients, like Gmail and Yahoo. The text will be displayed in your recipient's inbox, just below the subject.</p>


<label class="singel_sel_label label_desg">Select Profile</label><br>
<div id='send_id_con'>


<div class="cp-spinner cp-round"></div>

</div>

<span class="err_desg_of_camp" id="dt_of_ent_mail_se-mail_err" style="
"></span>

<p class="bel_ip_txt">Choose the email address to be shown in your recipients inbox when they receive your campaign or Add a new sender.</p>


<span class="err_desg_of_camp" id="dt_of_ent_mail_send-name_err" style="
"></span>

<p class="bel_ip_txt">Enter a name (e.g. your company name) to help campaign recipients recognize you in their inbox.</p>




<label class="singel_sel_label label_desg">Select SMTP Server</label><br>
<div id='smtp_serv_data'>


<div class="cp-spinner cp-round"></div>

</div>





<span class="err_desg_of_camp" id="dt_of_ent_mail_send-name_err" style="
"></span>

<p class="bel_ip_txt">Select Your SMTP server that you added in sycista account and send throught your Selected SMTP server.</p>







</div>

<div class="head_req_con" style="margin-right:3%">


<h2>Best for Preview Text in email</h2>

<p class="para_txt_for_info">get straight to your main point.</p>
<p class="para_txt_for_info">best to leave the subject line of your email messages short and concise.</p>

<p class="para_txt_for_info">strong action words in your preview text </p>

<p class="para_txt_for_info" style="border-bottom:none;">text to about 35-40 characters</p>

<img class="img-mob-appl" src="https://res.cloudinary.com/heptera/image/upload/v1596694495/IMG_20200806_113502_1_oulcy4.jpg" style="
    width: 100%;
">


</div>

</div>


<div class="step" id="step_3" style="width:70%;display:none">

<div class="meth_sel_temp">

<span class="span-sel-temp-method act-span-sel" id="desg_open">Design Tools</span>

<span class="span-sel-temp-method" id="mytemp_open">My Templates</span>



<span class="span-sel-temp-method" id="impotemp_open">Import Templates</span>






</div>





<div class="main-con-of-sel-con row" id="desg_opened">


<div class="card" style="width: 18rem;"  onclick="location.href='https://heptera.me/dash/main/template/';">
<h2>Drag And Drop Editor</h2>

  <img class="card-img-top" src="https://image.flaticon.com/icons/svg/838/838478.svg" height="100" width="100" alt="Card image cap">
  <div class="card-body">
    <p class="para_txt_for_info">Create a Mobile frendly template in editor.</p>
  </div>
</div>


<div class="card" style="width: 18rem;" data-toggle="modal" data-target="#rich_text_editor">
<h2>Rich Text Editor</h2>

  <img class="card-img-top" src="https://image.flaticon.com/icons/svg/2210/2210186.svg" height="100" width="100" alt="Card image cap">
  <div class="card-body">
    <p class="para_txt_for_info">Use the rich text editor to create simple emails</p>
  </div>
</div>



<div class="card" style="width: 18rem;" data-toggle="modal" data-target="#html_editor">
<h2>Copy Paste html Code</h2>

  <img class="card-img-top" src="https://image.flaticon.com/icons/svg/3208/3208391.svg" height="100" width="100" alt="Card image cap">
  <div class="card-body">
    <p class="para_txt_for_info">Copy and paste your<br> HTML code.</p>
  </div>
</div>
</div>


<div id="mytemp_opened">
<div id="temp_to_res" class="main-con-of-sel-con row" style="margin:0px;height:60vh;overflow:scroll"></div>

</div>


<div id="impotemp_opened" class="main-con-of-sel-con" style="display:none;">

<p class="bel_ip_txt" >You can import a template from another account on our platform by using a shared URL.
It is not possible to import a template created on other email marketing or third party platforms. Learn more</p>


<label class="singel_sel_label label_desg">Import Template</label>

<input type="text" class="ip-by-def-dsg" id="impo_url_temp" style="width:100%" >

<p class="bel_ip_txt" >Paste the shared link here.</p>

<button class="btn-theme-dsg sub_temp_crt_new" id="temp_impo">Import</button>
</div>

</div>





<div class="step" id="step_4" style="width:60%;display:none;overflow:scroll;">

<div class="main_rew_con">

<div class="contact-rew-con reviw-con">
<div class="rew-head-con">

<div class='re-txt-con-dv'>

<i class="fad fa-shield-check fa-rew-css" ></i>  <span class="rew-opt-con-css">Contact</span>

<span id="step-1-desg" data-step="step_1" class="ret_edit_step active" ><i class="fal fa-long-arrow-alt-left" style="
    padding-right: 5px;
"></i>Return to edit</span>

</div>

</div>
<div class="main-con">

<h4>Contact List :</h4>

<div id="con_lst_rev_handle"></div>


<h4>Audiance Filter :</h4>

<h5 style="color:green" id="filt_opt_hand_fr_ver">All subscriber</h5>

<h4 id="filt_head" >filter option :</h4>

<div id="filt_main_con_ver_data">

<span class="badge badge-dark badge-dark-active">employee</span></div>


<p class="bel_ip_txt" >Tag And Segment Filter apply In <span class="badge badge-dark badge-dark-active" style="background:blue">AND</span> Operation</p><br>
</div>

</div>

<div class="setup-rew-con reviw-con" style="border-top:0px;border-bottom:0px;">


<div class="rew-head-con">

<div class='re-txt-con-dv'>

<i class="fad fa-shield-check fa-rew-css" ></i>  <span class="rew-opt-con-css">Setup</span>

<span id="step-2-desg" data-step="step_2" class="ret_edit_step active"><i class="fal fa-long-arrow-alt-left" style="
    padding-right: 5px;
"></i>Return to edit</span>
</div>

</div>
<div class="main-con">
<div>
<h4 style="display:inline-block;">Subject : </h4>  <h5 id="sub_of_mail_pre_con" style="color:green;display:inline-block;">All subscriber</h5></div>

<div><h4 style="display:inline-block;">From : </h4>  <h5 id="frm_fld_for_pre" style="color:green;display:inline-block;">hepter&ltravigorasiya65@gmail.com></h5></div>

<div><h4 style="display:inline-block;">Mail Preview : </h4>  <h5 id="pre_of_mail_pre_con" style="color:green;display:inline-block;">No Preview</h5></div>

</div>



</div>


<div class="content-rew-con reviw-con">



<div class="rew-head-con">

<div class='re-txt-con-dv'>

<i class="fad fa-shield-check fa-rew-css" ></i>  <span class="rew-opt-con-css">Content</span>

<span id="step-3-desg" data-step="step_3" class="ret_edit_step active"><i class="fal fa-long-arrow-alt-left" style="
    padding-right: 5px;
"></i>Return to edit</span>

</div>

</div>
<div class="main-con row">

<div class="main-con-of-img-pre" id='temp-prev-shw'>

</div>

</div>



 

</div>

<div class="content-rew-con reviw-con">



<div class="rew-head-con">

<div class='re-txt-con-dv'>

<i class="fad fa-shield-check fa-rew-css" ></i>  <span class="rew-opt-con-css">Sheduled</span>

<span class="ret_edit_step"><i class="fad fa-clock" style="font-size:20px;"></i></span>

</div>

</div>
<div class="main-con">


<div class="sel_time_btn_con" style="width:100%;text-align:left;">





    <button class="btn btn-secondary btn-blck-non-fcs" id="send-test-btn" >Send<i class="fad fa-paper-plane" style="padding-left: 10px;"></i></button>

    <button class="btn btn-primary btn-blck-in-auta-fcs" id="send_email_test_ab" data-modal-trigger='ab_test_res' style="width:auto;" >A/b Testing<i class="fad fa-poll" style=" padding-left: 10px; "></i></button> 
<br>
<label class="singel_sel_label label_desg">Select Time</label><br>
<p class="bel_ip_txt" >Enter Sheduled time for campigns.</p>

  <button class="btn btn-primary btn-blck-in-auta-fcs" id="sel_time_for_camp" style="
    ">Select Time<i class="far fa-calendar-alt" style="padding-left: 10px;"></i></button>

  <div id="held_ver_data_of_camp"></div>



</div>
</div>



</div>
</div>

</div>



</div>



<div class="step" id="succ_div_of_set_camp" style="width: 60%; display: none; height: 82vh; overflow: scroll;">

<div class="vert-cent-div">

  <h2 class="head-of-txt-info">Campign Sheduled</h2>

<img class="info-err-img" src="https://res.cloudinary.com/heptera/image/upload/v1603875550/campign/undraw_schedule_pnbk_tu5p4j.svg">


<p class="dt-knw-abt-camp">Campign <span class="txt-hlght-in-para" id='shed-camp-name-suc'>new campigns3 </span>is Sheduled At Time <span class="txt-hlght-in-para" id='shed-dt-tm-suc'>2020-10-29 13:59:00</span>.</p>


<button class="btn_hover_clr"><i class="fal fa-long-arrow-alt-left" style="padding-right:10px;"></i>Back To DashBoard</button>


</div>
</div>


<div class='bottom-nav-of-camp-btn'>


<button type="button" class="btn btn-primary btn-blck-in-auta-fcs btn-for-sub-act" id="btn_sub_step-1">Next to Preview Field</button>
</div>




    
    
</div>




 












    
    </div>




   


</div>








<div class="modal" id="ab_test_res_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">A/B Testing Report</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">

<div class="per_def_tst_rat">
        <div class="spn-of-tst-ovr">
        <span class="per_def_of_test" id='id-of-scor-dt'>85</span>
        <span class="out-of-tst">/100</span>
    </div>
    
    </div>
<div id="accordion">
</div>    
   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

















<div class="modal " id="rich_text_editor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">Rich Text Editor</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true"><i class="fal fa-times-circle"></i></span>
</button>
</div>
<div class="modal-body">
<div id="editor_text_temp"></div>
</div>
<div class="modal-footer">
<a id="next_temp_btn" class="btn_in_txt_modl_nxt" style="display: none;float: right;color: rgb(0, 146, 255) !important;padding-right: 10px;">Next</a>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs sub_temp_crt_new " id="crt_rch_txt_temp">Create Template</button>
</div>
</div>
</div>
</div>






<div class="modal fade" id="html_editor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">HTML Editor</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true"><i class="fal fa-times-circle"></i></span>
</button>
</div>
<div class="modal-body">
<div id="">
<textarea class="txt_are_desg" id="html_edt_txt_ar"></textarea>
</div>
</div>
<div class="modal-footer">
<a id="next_temp_btn" class="btn_in_html_modl_nxt" style="display: none;float: right;color: rgb(0, 146, 255) !important;padding-right: 10px;">Next</a>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="crt_html_txt_temp">Create Template</button>
</div>
</div>
</div>
</div>










</body></html>


<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>



<script type="text/javascript">






$('[data-toggle="tooltip"]').tooltip();

id='<?php echo $id;?>';






data_abt_next_act=[{'name':'Next to Preview Field','btn_act':'btn_sub_step-1'},{'name':'Select Template','btn_act':'btn_sub_step-2'},{'name':'Preview campign','btn_act':'next_temp_btn'},{'name':'Create Campign','btn_act':'edt_shed_data_final_step'}]






main_url_of_page="http://heptera.me/dash/main/template/crt-template/crtedtemp/";


con_of_btn_if_err="";


id_for_temp="";
camp_tp_flg="new";

error_code_to_next_step=0;
camp_name_def="";

name_of_crt="<?php echo $get_camp_id;?>";
camp_con_id="";


sel_opt_lable_val_data={};



//step_2 data 

sub_of_mail="";
pre_of_mail="";
send_mail="<?php echo $mail;?>";
send_mail_name="";
smtp_id="";

//step 1 data


err_flg_of_save_name=0;

email_list_arr=[];
merge_fld="";
filt_json_data={};
filt_data_sel_obj={};

time_data="";

//step 3 data



temp_def_name="";

temp_sel_data="";









pres_lst_ele=[];
tag_get=[];
tag_get_seg_data=[];

res_seg='';
res_tag='';








///main-reviw-step-4 data


data_of_list=[];


data_of_filt_data=[];



////step-4 variable



camp_id_for_temp="";


function set_step_2_data(json){





$("#sub_ip_fld").val(json.content_db['sub_fld']);


$("#pre_ip_fld").val(json.content_db['prev_fld']);


$("#frm_email").val(json.content_db['frm_email']);


$("#frm_name").val(json.content_db['frm_name']);

}


function set_step_1_data(json){

$(".ip_of_merg_fld").val(json.merge_fld);

}




function set_camp_data(){

$("#name_hld_crt").html(name_of_crt+'<div class="con-of-edt-name" id="clc_on_edt_crt"> <img src="https://res.cloudinary.com/heptera/image/upload/v1628333996/campign/create_black_24dp_twq8d8.svg" class="ico-dsg-shd"> </div>');


if(name_of_crt!="new campigns"){



$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/get_camp_data.php",
  data:{camp_id:name_of_crt}
 
}).done(function(response1) {


json_data=JSON.parse(response1);

console.log(json_data);

camp_id_for_temp=id_for_temp+"^"+name_of_crt;

camp_con_id=json_data.camp_con_id;

set_step_1_data(json_data);

set_step_2_data(json_data);




});


}
}




$(document).ready(function(){

set_camp_data();



$(".navbar").css("position","inherit");

//$('#editor_text_temp').summernote({
  //      placeholder: "hello world",
    //    tabsize: 2,
      //  height: 100
//});
//
var quill = new Quill('#editor_text_temp', {

theme: 'snow'
  });

})

















function get_init_auto_comp_data(data_id_con,data){


json = JSON.parse(data);     

data_of_list=json;

console.log(data_id_con);

var autocomplete = new SelectPure("."+data_id_con, {
        options: json,
        value: [],
        multiple: true,
        autocomplete: true,
        icon: "fa fa-times",
        onChange: value => { tag_get=value; },
        classNames: {
          select: "select-pure__select",
          dropdownShown: "select-pure__select--opened",
          multiselect: "select-pure__select--multiple",
          label: "select-pure__label",
          placeholder: "select-pure__placeholder",
          dropdown: "select-pure__options",
          option: "select-pure__option",
          autocompleteInput: "select-pure__autocomplete",
          selectedLabel: "select-pure__selected-label",
          selectedOption: "select-pure__option--selected",
          placeholderHidden: "select-pure__placeholder--hidden",
          optionHidden: "select-pure__option--hidden",
        }
      });


function append_tag(item, index){
  let op = json.filter(e=> e.value == item);
  
$("#tag_ver_con").append("<span class='select-pure__selected-label'>"+op[0]['label']+"</span>");


}


}


function get_init_auto_comp_seg_data(data_id_con,data){




tag_get_seg_data=[];
json = JSON.parse(data);     


console.log(json);

for (var i = 0; i < json.length; i++) {
  filt_data_sel_obj[json[i].value]=json[i].label;
};

console.log( filt_data_sel_obj);


data_of_filt_data=json;

console.log(data_id_con);

var autocomplete_2 = new SelectPure(".autocomplete-select-seg", {
        options: json,
        value: [],
        multiple: true,
        autocomplete: true,
        icon: "fa fa-times",
        onChange: value => { tag_get_seg_data=value},
        
      });


function append_tag(item, index){
  let op = json.filter(e=> e.value == item);
  


console.log(sel_seg_tag_test);
$("#tag_ver_con").append("<span class='select-pure__selected-label'>"+op[0]['label']+"</span>");


}


}


function get_list_val(json_data_to_lst){

ret_arr=[];
lst_dt=JSON.parse(json_data_to_lst);

console.log(lst_dt);

for (var i = 0; i < lst_dt.length; i++) {
  
ret_arr.push(lst_dt[i]['value']);


};

pres_lst_ele=ret_arr;

}

function get_aud_data(){



$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/get_list_of_id.php"
 
}).done(function(response1) {

console.log(response1);
        get_init_auto_comp_data("autocomplete-select",response1);

   
    get_list_val(response1);
   


get_seg_data("");

});


}



function get_seg_data(data_flg){

console.log(tag_get);

pres_lst_jsn=JSON.stringify(tag_get);


$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/get_seg_acc_list.php",
  data:{list_name:pres_lst_jsn}
 
}).done(function(response1) {



        console.log(response1);
 
get_init_auto_comp_seg_data("",response1);



});


}


function get_tag_data(){

pres_lst_jsn=JSON.stringify(pres_lst_ele);

console.log(pres_lst_jsn);

$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/get_tag_data_lst.php",
  data:{list_name:pres_lst_jsn}
 
}).done(function(response1) {



get_init_auto_comp_seg_data("",response1);


});


}




$(document).on('change',"#sel_opt_tp_chg",function(){

val_of_opt=$(this).val();

$(".con_of_sel_data_seg").empty();


if(val_of_opt=="segment"){
get_seg_data("");

$(".con_of_sel_data_seg").html('<label class="multi_sel_label label_desg">Select Field</label><br><span class="autocomplete-select-seg"></span>');

}else if(val_of_opt=="tag"){

get_tag_data("");

$(".con_of_sel_data_seg").html('<label class="multi_sel_label label_desg">Select Field</label><br><span class="autocomplete-select-seg"></span>');
}

$(".con_of_sel_data_seg").css("display","block");

});






$(document).ready(function(){
get_aud_data();








});






























function save_camp_name(){



$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/save_camp_name.php",
  data:{camp_name:camp_name_def,old_name:name_of_crt,time_data:time_data}
 
}).done(function(response1) {

console.log(response1);

  if(response1==0){


err_flg_of_save_name=1;


 err_msg_data('Please Select Valid name.');

}else{


if(response1==1){

err_flg_of_save_name=1;

 err_msg_data('Please Select Valid name.');

}else{

camp_con_id=response1;


err_flg_of_save_name=0;

}

$("#dt_of_crt_err").html("");

camp_id_for_temp=id_for_temp+"^"+camp_name_def;


err_flg_of_save_name=0;
$("#name_hld_crt").html(camp_name_def+'<div class="con-of-edt-name" id="clc_on_edt_crt"> <img src="https://res.cloudinary.com/heptera/image/upload/v1628333996/campign/create_black_24dp_twq8d8.svg" class="ico-dsg-shd"> </div>');

}

});





}






$(document).on('click',"#clc_on_edt_crt",function(){

name_of_crt=$("#name_hld_crt").text();


name_of_crt=name_of_crt.substring(0,name_of_crt.length - 1);
console.log(name_of_crt);
$("#name_hld_crt").html('<input id="crt_dt_name" class="ip-by-def-dsg edt_of_ip_fld" value="'+name_of_crt+'" type="text" style=""><span class="err_desg_of_camp" id="dt_of_crt_err"></span>');



})



$(document).mouseup(function(e) 
{
    var container = $("#name_hld_crt");

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {




 camp_name_def=$("#crt_dt_name").val();


      if( camp_name_def!="new campigns " ){
        if ($('#crt_dt_name').length != 0) {

         


save_camp_name();



       


}
}else{




 err_msg_data('Please Select Valid name.');

  }



set_camp_temp_next_btn();
   


  }

  
});







function camp_name_val_fun(){


if(($("#name_hld_crt").text().length>0 && $("#name_hld_crt").text()!="new campigns") && camp_name_def!="new campigns"){



return 1;


}else{




 err_msg_data('Please Select Valid name.');

return 0;



}


}



function btn_set_next_sub_act(next_act){



act_name=data_abt_next_act[next_act].name;
act_field=data_abt_next_act[next_act].btn_act;

$('.btn-for-sub-act').html(act_name);

$('.btn-for-sub-act').attr('id',act_field);
$('.btn-for-sub-act').prop('disabled',false);
}



function save_lst_data_in_db(){

merg_fld_send=merge_fld;

list_dt_send=JSON.stringify(email_list_arr);

filt_data_send=JSON.stringify(filt_json_data);




$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/save_lst_data.php",
  data:{merge_fld:merg_fld_send,list_data:list_dt_send,filt_opt:filt_data_send,con_id:camp_con_id}
 
}).done(function(response1) {


append_nxt_lbl("#btn_sub_step-1");
console.log(response1);


if(response1==1){


  $("#step-2-desg").addClass("active");

$("#step_1").css("display","none");

$("#step_2").css("display","flex");

init_sender_data();

init_smtp_data();


btn_set_next_sub_act(1);


}else{


  $("#dt_of_comm_err").html("Internal Error to, Try After Some Time");



}





});


}










function valid_data_step_1(){


$("#dt_of_comm_err").html("");
flg_val_fld=0;

filt_json_data={};

merge_fld=$(".ip_of_merg_fld").val();


val_field_dt=$("#sel_opt_tp_chg").val();

if(tag_get.length!=0){


email_list_arr=tag_get;






if(val_field_dt=="tag" || val_field_dt=="segment"){

if(tag_get_seg_data.length==0){





  flg_val_fld=1;


}else{


filt_json_data["name"]=val_field_dt;
  filt_json_data["data"]=tag_get_seg_data;
}

}else{


filt_json_data["name"]=val_field_dt;

}

if(flg_val_fld==0){


return 1;


}else{




 err_msg_data("Select Field From Audiance");

}



}else{


err_msg_data("Select Audiance From Contact List");

}

}


$(document).on('click',"#btn_sub_step-1",function(){


console.log($.trim($("#name_hld_crt").text())=="new campigns");

if(($.trim($("#name_hld_crt").text())=="new campigns" || $.trim($("#crt_dt_name").val())=='new campigns ') || err_flg_of_save_name==1){



 err_msg_data('Please Select Valid name.');

}else{

if(camp_name_val_fun()){

ret_val_flg_val=valid_data_step_1();

if(ret_val_flg_val){


append_load("#btn_sub_step-1");


save_lst_data_in_db();


}

}

}


});
function validateEmail(sEmail){
      var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;

  if(!sEmail.match(reEmail)) {
    


    return false;
  }

  return true;

}


function val_step_2(){

sub_of_mail=$("#sub_ip_fld").val();

if(!(sub_of_mail.length>0)){
 
 err_msg_data("Enter Subject Of Mail.");


  return 0;
}



pre_of_mail=$("#pre_ip_fld").val();


if(!(pre_of_mail.length>0)){



err_msg_data("Enter Preview Of Mail For Recognize by Your User.");


return 0;

}



send_mail=$("#frm_pro").val();


smtp_id=$("#smtp_sel_id").val();

temp_def_name="";


return 1;

}



function sub_step_2(stp_nxt_id){




$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/save_content_data.php",
  data:{temp_name:temp_def_name,mail_sub:sub_of_mail,mail_pre:pre_of_mail,sender_id:send_mail,smtp_id:smtp_id,con_id:camp_con_id}
 
}).done(function(response1) {

console.log(response1);
if(response1==1){

step_deg=stp_nxt_id-1;

  $("#step-"+stp_nxt_id+"-desg").addClass("active");

$("#step_"+step_deg).css("display","none");


$("#step_"+stp_nxt_id).css("display","block");


btn_set_next_sub_act(stp_nxt_id-1);


}else{

console.log("error in content data save");

}






});


}


$(document).on("click","#btn_sub_step-2",function(){



remove_err_all_con();

if(val_step_2()){


append_load("#btn_sub_step-2");

sub_step_2(3);
}

 
 

});













function set_temp_data(){


$.ajax({
    url : './ajaxfile/get_all_temp_data.php',
    type: 'POST',
    data : {'id_to_get_data':id_for_temp}
  }).done(function(response){ //
   

console.log(response);

   var get_res_temp=JSON.parse(response);
    
    
$("#temp_to_res").empty();
 length_of_array=get_res_temp.length;

 if(length_of_array>0){
        for(i=0;i<length_of_array;i++){    
temp_thumb(get_res_temp[i]['name'],get_res_temp[i]['dateofcrt']);


  } 
    
    }else{




$("#temp_to_res").html('<div class="not-fd-temp-in-acc"> <svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" fill="currentColor" class="bi bi-diagram-3" viewBox="0 0 16 16" style=" color: #f2f2f2; "> <path fill-rule="evenodd" d="M6 3.5A1.5 1.5 0 0 1 7.5 2h1A1.5 1.5 0 0 1 10 3.5v1A1.5 1.5 0 0 1 8.5 6v1H14a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-1 0V8h-5v.5a.5.5 0 0 1-1 0V8h-5v.5a.5.5 0 0 1-1 0v-1A.5.5 0 0 1 2 7h5.5V6A1.5 1.5 0 0 1 6 4.5v-1zM8.5 5a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1zM0 11.5A1.5 1.5 0 0 1 1.5 10h1A1.5 1.5 0 0 1 4 11.5v1A1.5 1.5 0 0 1 2.5 14h-1A1.5 1.5 0 0 1 0 12.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm4.5.5A1.5 1.5 0 0 1 7.5 10h1a1.5 1.5 0 0 1 1.5 1.5v1A1.5 1.5 0 0 1 8.5 14h-1A1.5 1.5 0 0 1 6 12.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm4.5.5a1.5 1.5 0 0 1 1.5-1.5h1a1.5 1.5 0 0 1 1.5 1.5v1a1.5 1.5 0 0 1-1.5 1.5h-1a1.5 1.5 0 0 1-1.5-1.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1z"></path> </svg><br> <span class="temp-not-fd-txt">In your account not found any template</span> <br><button type="button" class="btn-theme-dsg" id="next_temp_btn" style=" max-width: 200px; margin-top: 30px; height: inherit; padding: 10px; ">Create New Template<i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button> </div>');



    }
    
  });


}







function temp_thumb(temp_id,temp_crt_date){



temp_dis_name=atob(temp_id.split("^")[1]);

var str_for_temp_res='<div class="auta-main-dis-dash temp_con" id="'+temp_id+'"> <div class="main-con-img-temp" style="background-image:url(https://scr.auftera.com/scr-api/?url=https://template.auftera.com/template/crt-template/crtedtemp/'+temp_id+'.html&amp;width=700&amp;height=800)"> <span class="bdg-tp-btn">'+temp_dis_name+'</span> </div> <div class="def_stat-of-dt"> <div class="con-of-cnt-data data_red_btn_ld" data-trg-url="./edit/?temp_id='+temp_id+'">Edit</div> <div class="con-of-dp-data" style=""> <div class="dropdown" style=" height: 32px; "> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="https://res.cloudinary.com/heptera/image/upload/v1621831794/dashboard/more_horiz_black_24dp_kiwldy.svg" class="img-of-act"> </button>  </div> </div> </div> </div>';

$("#temp_to_res").append(str_for_temp_res);




}




function get_screen_shot(id_of_url){
  
    url=main_url_of_page+id_of_url+".html";
  url_main="http://ec2-3-21-105-231.us-east-2.compute.amazonaws.com/scr-api/?url="+url+"&width=700&height=800"; 



    $("#img-of-temp").attr("src",url_main);
    $("#img-of-temp").attr("id",id_of_url);

//document.getElementById(id_of_url+"img").src=url_main;

console.log(id_of_url);
}



$(document).on("click",".span-sel-temp-method",function(){



  temp_def_name="";

$('.span-sel-temp-method').map(function() {
    
var tag_id=$(this).attr("id");

$("#"+tag_id+"ed").css("display","none");

$(this).removeClass('act-span-sel');

});

$(this).addClass("act-span-sel");


open_tag=$(this).attr("id");

$("#"+open_tag+"ed").css("display","inherit");

if(open_tag=="mytemp_open"){




$("#temp_to_res").empty();

$("#temp_to_res").html('<div class="lds-ring lds-color" style=" margin: auto; "><div></div><div></div><div></div><div></div></div>');

set_temp_data();



}else if(open_tag=="desg_open"){

$("#"+open_tag+"ed").css("display","flex");


}


set_camp_temp_next_btn();

});



$(document).on("click",".temp_con",function(){


temp_def_name=$(this).attr("id");


$('.temp_con').map(function() {
    
$(this).removeClass("temp_con_active");

});

$(this).addClass("temp_con_active");

set_camp_temp_next_btn();


});






function set_camp_temp_next_btn(){




if(temp_def_name.length==0){




}else{





}


}






function sub_impo_frm_url(){

append_load("#temp_impo");

val_of_url=$("#impo_url_temp").val();



$.ajax({
    url : "https://template.auftera.com/template/crt-template/ajaxfile/crt_temp_from_url.php",
    type: 'POST',
    data : {id:id,temp_url:val_of_url,camp_id:camp_con_id}
  }).done(function(response){ //
   
  
    temp_def_name=response;

$("#temp_impo").prop('disabled', false);
$("#temp_impo").html("Import");

err_msg_data("Import Template Successfully");
    
  });




}

function cls_mdl(sel){

	$(sel).hide();
	$('.modal-backdrop').remove();

}


function sub_norm_frm_url(txt_data){


	



$.ajax({
    url : "https://template.auftera.com/template/crt-template/ajaxfile/save_norm_temp.php",
    type: 'POST',
    data : {temp_code_data:txt_data,camp_id:camp_con_id,id:id}
  }).done(function(response){ //
   
   console.log(response);
    
    temp_def_name=response;
cls_mdl("#rich_text_editor");
 cls_mdl("#html_editor");


err_msg_data("Template Created Successfully");   
  });


}

$(document).on("click",".sub_temp_crt_new",function(){

temp_con_impo_tp=$(this).attr("id");



if(temp_con_impo_tp=="temp_impo"){


sub_impo_frm_url();



}else if(temp_con_impo_tp=="crt_rch_txt_temp"){

sub_norm_frm_url($(".ql-editor").html());



}else if(temp_con_impo_tp=="crt_html_txt_temp"){

sub_norm_frm_url($("#html_edt_txt_ar").val());



}

});


function filt_data_set_in_ver_tab(){

str_con_lst="";

console.log(filt_json_data['data']);
console.log(filt_data_sel_obj);

for (var i = 0; i < filt_json_data['data'].length; i++) {
  
list_name=filt_data_sel_obj[filt_json_data['data'][i]];

str_con_lst+='<span class="badge badge-dark badge-dark-active">'+list_name+'</span>';

};



$("#filt_main_con_ver_data").html(str_con_lst);

$("#filt_head").css("display","block");

$("#filt_main_con_ver_data").css("display","block");

}


function init_merge_fld_fr_ver(){

$("#filt_head").css("display","none");

$("#filt_main_con_ver_data").css("display","none");

var merge_fld_2=filt_json_data["name"];

console.log(filt_json_data);

if(merge_fld_2=="all_sub"){

$("#filt_opt_hand_fr_ver").html("All Subscriber");

}else if(merge_fld_2=="tag"){

$("#filt_opt_hand_fr_ver").html("Tag");


filt_data_set_in_ver_tab();

}else if(merge_fld_2=="segment"){

$("#filt_opt_hand_fr_ver").html("Segment");


filt_data_set_in_ver_tab();


}else if(merge_fld_2=="new_sub"){

$("#filt_opt_hand_fr_ver").html("New Subscriber");

}else if(merge_fld_2=="act_sub"){

$("#filt_opt_hand_fr_ver").html("Active Subscriber");

}else if(merge_fld_2=="inact_sub"){

$("#filt_opt_hand_fr_ver").html("Inactive Subscriber");

}



}



function init_con_lst_in_ver(){

console.log(email_list_arr);
str_con_lst="";
for (var i = 0; i < email_list_arr.length; i++) {
  

list_name=email_list_arr[i].split("^")[1];

list_name=atob(list_name);

  str_con_lst+='<span class="badge badge-dark badge-dark-active">'+list_name+'</span>';




};







$("#con_lst_rev_handle").html(str_con_lst);

}




function init_sub_pre_data(){

$("#sub_of_mail_pre_con").html(sub_of_mail);

$("#frm_fld_for_pre").html(send_mail_name+" < "+send_mail+" >");

$("#pre_of_mail_pre_con").html(pre_of_mail);

}



function init_step_4_data(){



init_con_lst_in_ver();

init_merge_fld_fr_ver();


init_sub_pre_data();


init_temp_data();

}









function init_temp_data(){


console.log(temp_def_name);


name_org_show=atob(temp_def_name.split("^")[1]);

$("#temp-prev-shw").html('<div class="auta-main-dis-dash temp_con temp_con_active" id="497889959^cHJvZHVjdC1vdmVyLWNvcHk=" style=" margin: auto; "> <div class="main-con-img-temp" style="background-image:url(https://scr.auftera.com/scr-api/?url=https://template.auftera.com/template/crt-template/crtedtemp/'+temp_def_name+'.html&amp;width=700&amp;height=800)"> <span class="bdg-tp-btn">'+name_org_show+'</span> </div> <div class="def_stat-of-dt"> <div class="con-of-cnt-data com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/edit/?temp_id='+temp_def_name+'">Edit</div> <div class="con-of-dp-data" style=""> <div class="dropdown" style=" height: 32px; "> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="https://res.cloudinary.com/heptera/image/upload/v1621831794/dashboard/more_horiz_black_24dp_kiwldy.svg" class="img-of-act"> </button>  </div> </div> </div> </div>');



}


























$(document).on("click","#next_temp_btn",function(){


if(temp_def_name.length>0){

$('#rich_text_editor').modal('hide');
$('#html_editor').modal('hide')

append_load("#next_temp_btn");

 init_step_4_data();

 sub_step_2(4);

}else{
    err_msg_data('Please Select valid template');
}


});


$(document).on("click",".active",function(){

$('.step').map(function() {
    
$(this).css("display","none");

});


send_data_con=$(this).attr("data-step");

container_of_data="#"+send_data_con;
$(container_of_data).css("display","block");

if(send_data_con=="step_2"){

  $(container_of_data).css("display","flex");
}


btn_set_next_sub_act(parseInt(send_data_con[send_data_con.length-1])-1);



});



function set_rev_list_data(){

console.log(data_of_list);


console.log(data_of_filt_data);



}

$(document).on("click","#test",function(){


 set_rev_list_data();


});


function val_time_dt(time_date_val){




$.ajax({
    url : "./ajaxfile/crt-camp/date_val_for_crt_camp.php",
    type: 'POST',
    data : {ip_for_time_sel_camp:time_date_val}
  }).done(function(response){ //
   console.log(response);

  if(response==1){

$("#held_ver_data_of_camp").html(time_date_val);

$("#held_ver_data_of_camp").css('color',"green");


time_data=time_date_val;

  }else{

    $("#held_ver_data_of_camp").html("please select valid date");
    $("#held_ver_data_of_camp").css('color',"red");
  }
    
  });


}

let simplepicker = new SimplePicker({
      zIndex: 10
    });

    

    $(document).on("click","#sel_time_for_camp",function(){

simplepicker.open();

    })
   

    // $eventLog.innerHTML += '\n\n';
    simplepicker.on('submit', (date, readableDate) => {
    
      val_time_dt(readableDate);

    });



function remove_err_all_con(){

$('.err_desg_of_camp').map(function() {
    
$(this).empty();

});


}



function save_camp_shed_time(){

list_dt_send=JSON.stringify(email_list_arr);


$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/save_camp_shed_time.php",
  data : {time_data:time_data,camp_id:camp_con_id,lst_dt:list_dt_send}
 
}).done(function(response1) {



if(response1==1){


init_suc_step_data();

}else{

	err_msg_data(response1);


}

});



}


function init_suc_step_data(){



$("#succ_div_of_set_camp").css('display','block');

$("#step_4").css('display','none');


$("#shed-camp-name-suc").html($("#name_hld_crt").text());

$("#shed-dt-tm-suc").html(time_data);

}

function set_temp_name_dt(){



  append_load("#edt_shed_data_final_step");

$.ajax({
  type: "POST",
  url: "./ajaxfile/crt-camp/set_temp_data_in_db_url.php",
  data : {camp_id:camp_con_id,temp_id:temp_def_name}
 
}).done(function(response1) {


	console.log(response1);

    save_camp_shed_time();    

});


}


$(document).on("click","#edt_shed_data_final_step",function(){





if(time_data.length>0){


  set_temp_name_dt();



}else{
  

  




}



});



function init_sender_data(){





$.ajax({
  type: "POST",
  url: "./ajaxfile/get_all_sender_data.php",
  data : {camp_id:camp_con_id,temp_id:temp_def_name}
 
}).done(function(response1) {


console.log(response1);
data_of_send=JSON.parse(response1);


str_of_app=str_of_send_info(data_of_send);

$("#send_id_con").html(str_of_app);


     

});


}


function str_of_send_info(data){

str_app='<select class="ip-by-def-dsg" id="frm_pro">';

for (var i = 0; i < data.length; i++) {
 
 str_app+='<option value="'+data[i]['sender_id']+'">'+data[i]['email']+'</option>'

};

str_app+='</select>';

return str_app;


}




function init_smtp_data(){





$.ajax({
  type: "POST",
  url: "./ajaxfile/get_all_smtp_server.php"
 
}).done(function(response1) {

console.log(response1);

data_of_send=JSON.parse(response1);

console.log(data_of_send);

str_of_app=str_of_smtp_data(data_of_send);

$("#smtp_serv_data").html(str_of_app);


     

});


}


function str_of_smtp_data(data){



str_app='<select class="ip-by-def-dsg" id="smtp_sel_id">';

str_app+='<option value="10000">Sycista SMTP</option>'

for (var i = 0; i < data.length; i++) {
 
 str_app+='<option value="'+data[i]['smtp_id']+'">'+data[i]['smtp_name']+'</option>'

};

str_app+='</select>';

return str_app;


}



function append_load(sel){

$(sel).prop('disabled', true);
  $(sel).html('<div class="cp-spinner cp-round"></div>');

}


function append_nxt_lbl(sel){

  $(sel).prop('disabled', false);
  $(sel).html('Next<i class="fal fa-long-arrow-right" style="padding-left:10px;"></i>');

}


function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})

















function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    const close = modal.querySelector('.close');

    close.addEventListener('click', () => modal.classList.remove('open'));
    

    modal.classList.toggle('open');
  
}

$(document).on('click','.cls_mdl_opn',function(){


attr_rem=$(this).attr('data-target-rem');

$("#"+attr_rem).removeClass('open');

})



$(document).on('click','#send_email_test_ab',function(){
$("#ext_ele_of_othr_rst").remove();
console.log("send_for_");
	$('<div class="cp-spinner cp-round" id="ext_ele_of_othr_rst" style="top: 8px;margin-left: 10px;"></div>').insertAfter('#send_email_test_ab');


init_all_data_blnk_add_ldr();





$.ajax({
  type: "GET",
  url: "./ab_testing/ajaxfile/get_email_ab.php?temp_id="+temp_def_name+"&sub_test="+sub_of_mail
 
}).done(function(response1) {

	console.log(response1);

ab_get_data=JSON.parse(response1);
     
console.log(ab_get_data);

     init_score_of_ab_test(ab_get_data.score);


     init_asp_of_ab_tst(ab_get_data.aspect_of);

});




})


function init_all_data_blnk_add_ldr(){


$("#dt_of_rng").removeClass("over50");


}


function init_asp_of_ab_tst(data_shwn){



ico_str_blb='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M4 9C4 11.9611 5.60879 14.5465 8 15.9297V15.9999C8 18.2091 9.79086 19.9999 12 19.9999C14.2091 19.9999 16 18.2091 16 15.9999V15.9297C18.3912 14.5465 20 11.9611 20 9C20 4.58172 16.4183 1 12 1C7.58172 1 4 4.58172 4 9ZM16 13.4722C17.2275 12.3736 18 10.777 18 9C18 5.68629 15.3137 3 12 3C8.68629 3 6 5.68629 6 9C6 10.777 6.7725 12.3736 8 13.4722L10 13.4713V16C10 17.1045 10.8954 17.9999 12 17.9999C13.1045 17.9999 14 17.1045 14 15.9999V13.4713L16 13.4722Z" fill="currentColor"></path><path d="M10 21.0064V21C10.5883 21.3403 11.2714 21.5351 12 21.5351C12.7286 21.5351 13.4117 21.3403 14 21V21.0064C14 22.111 13.1046 23.0064 12 23.0064C10.8954 23.0064 10 22.111 10 21.0064Z" fill="currentColor"></path></svg>';

str_of_app="";
for (var i = 0; i < 6; i++) {


fact_str=get_fact_string_of_fld(data_shwn[i].factor.data);


if(data_shwn[i].passed_val){

clr_name="green";

}else{
  clr_name="red";
}


name_of_fld=get_name_of_aspct(data_shwn[i].name);
msg_fld=data_shwn[i].message;
status_of_fld=data_shwn[i].status;

str_of_app+='<div class="card card-2" style=" "> <div class="card-header" id="headingOne" style=" padding: 0px; "> <div class="btn btn-link collapsed" data-toggle="collapse" data-target="#'+data_shwn[i].name+'" aria-expanded="false" aria-controls="collapseOne"> <table class="ab-test-data"> <tbody class="tbl_body"> <tr style="display: table-row;"> <td class="tbl-column-ab_test" style=" padding: 20px; color: '+clr_name+'; ">  '+ico_str_blb+status_of_fld+' </td> <td class="tbl-column-ab_test" style=" color: black; font-weight: 700; "> '+name_of_fld+' </td> <td class="tbl-column-ab_test collapsed" style="color: black;" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"> '+msg_fld+' </td> </tr> </tbody> </table> </div> </div> <div id="'+data_shwn[i].name+'" class="collapse" aria-labelledby="headingOne" data-parent="#accordion" style=""> <div class="card-body"><div class="head-of-ab-tst-tru" style="background:'+clr_name+'"> '+msg_fld+' </div> <div class="all-con-of-fctr"> '+fact_str+' </div></div> </div> </div>';


};


$("#accordion").html(str_of_app);

}


function get_fact_string_of_fld(arr_fact_data){


ico_blb='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M4 9C4 11.9611 5.60879 14.5465 8 15.9297V15.9999C8 18.2091 9.79086 19.9999 12 19.9999C14.2091 19.9999 16 18.2091 16 15.9999V15.9297C18.3912 14.5465 20 11.9611 20 9C20 4.58172 16.4183 1 12 1C7.58172 1 4 4.58172 4 9ZM16 13.4722C17.2275 12.3736 18 10.777 18 9C18 5.68629 15.3137 3 12 3C8.68629 3 6 5.68629 6 9C6 10.777 6.7725 12.3736 8 13.4722L10 13.4713V16C10 17.1045 10.8954 17.9999 12 17.9999C13.1045 17.9999 14 17.1045 14 15.9999V13.4713L16 13.4722Z" fill="currentColor"></path><path d="M10 21.0064V21C10.5883 21.3403 11.2714 21.5351 12 21.5351C12.7286 21.5351 13.4117 21.3403 14 21V21.0064C14 22.111 13.1046 23.0064 12 23.0064C10.8954 23.0064 10 22.111 10 21.0064Z" fill="currentColor"></path></svg>';

str_of_fact="";

slv_ico='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.46457 14.1213C8.07404 14.5118 8.07404 15.145 8.46457 15.5355C8.85509 15.926 9.48825 15.926 9.87878 15.5355L15.5356 9.87862C15.9262 9.4881 15.9262 8.85493 15.5356 8.46441C15.1451 8.07388 14.5119 8.07388 14.1214 8.46441L8.46457 14.1213Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M6.34315 17.6569C9.46734 20.781 14.5327 20.781 17.6569 17.6569C20.781 14.5327 20.781 9.46734 17.6569 6.34315C14.5327 3.21895 9.46734 3.21895 6.34315 6.34315C3.21895 9.46734 3.21895 14.5327 6.34315 17.6569ZM16.2426 16.2426C13.8995 18.5858 10.1005 18.5858 7.75736 16.2426C5.41421 13.8995 5.41421 10.1005 7.75736 7.75736C10.1005 5.41421 13.8995 5.41421 16.2426 7.75736C18.5858 10.1005 18.5858 13.8995 16.2426 16.2426Z" fill="currentColor" /></svg>';


for (var i = 0; i < arr_fact_data.length; i++) {
  




if(arr_fact_data[i].passed_val){

clr_name="green";

}else{
  clr_name="red";
}

name_of_fact= get_name_of_aspct(arr_fact_data[i].id);
title_of_fact=arr_fact_data[i].title;
desc_of_fact=arr_fact_data[i].desc;
solv_of_fact=arr_fact_data[i].solution;

  str_of_fact+='<table class="ab-test-data"> <tbody class="tbl_body"> <tr style="display: table-row;"> <td class="tbl-column-ab_test" style=" padding: 20px; color: '+clr_name+'; ">  '+ico_blb+name_of_fact+' </td> <td class="tbl-column-ab_test" style=" color: black; font-weight: 700; "> '+title_of_fact+' </td> <td class="tbl-column-ab_test " style="color: black;" > '+desc_of_fact+' </td> </tr> </tbody> </table><div class="solv_con-of-fact"> '+slv_ico+'<br>'+solv_of_fact+'</div>';


};



return str_of_fact;







}


function get_name_of_aspct(type_of_aspct){



return type_of_aspct.replace("_"," ");

}

function init_score_of_ab_test(scr_data){


	$("#id-of-scor-dt").html(scr_data);

$("#ext_ele_of_othr_rst").remove();
	$('<div class="ext-res-opn-mdl" id="ext_ele_of_othr_rst" style="" data-toggle="modal" data-target="#ab_test_res_mdl">Open A/B Result</div>').insertAfter('#send_email_test_ab');




}










$(document).on('click','#send-test-btn',function(){



$.ajax({
                url : "./ajaxfile/send_email_test.php",
                type: "POST",
                data : {temp_id:temp_def_name,sub_mail:sub_of_mail,prev_txt:pre_of_mail}
        }).done(function(response){


res_data=JSON.parse(response);
		
		if(res_data.status==1){


			err_msg_data("Testing Email Send To User Email");
}else{


	err_msg_data(res_data.message);

		}

});



})





err_msg_data("Welcome To Studio");


function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})




</script>
