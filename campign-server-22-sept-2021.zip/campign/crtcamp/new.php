<?php



$selectfilenme = "SELECT * FROM filedetails WHERE id='$id'";
$filenamefind = $conn2->query($selectfilenme);

if ($filenamefind->num_rows > 0) {
    // output data of each row
    while($row = $filenamefind->fetch_assoc()) {
        $filename2=$row['filename'];
       $getorgfilename=explode( '^', $filename2 );
       $filename1=base64_decode($getorgfilename[1]);
       ?>
<div class="addlist" data-select-list="<?php echo $filename1;?>" data-select="0" data-select-encode="<?php echo $filename2;?>" onclick="addlist(this)" id="<?php echo $row['extra'];?>" style="width:100%;border-radius:5px;padding:8px;">
<?php echo $filename1;?><span class="badge badge-primary" style="background:#007bff;float:right;letter-spacing:20px;font-size:15px;"><?php echo $row["extra"];?><i class="fas fa-envelope" ></i></span></div><br>
       <?php
    

    }
}


?>