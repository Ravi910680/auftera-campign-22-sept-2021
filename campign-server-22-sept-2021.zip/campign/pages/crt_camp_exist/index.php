<?php

session_start();

require("../../confige/camp_confige.php");

$mail="ravigorasiya65gmail.com";

$id=$_SESSION['id'];

if(isset($_GET['camp_id'])){
$get_camp_id=$_GET['camp_id'];

$sel_data_temp_ver="select * from camp_name_tbl where camp_name='".$get_camp_id."'";

$res=$camp_name_conn->query($sel_data_temp_ver);

if($res->num_rows > 0){

while($row = $res->fetch_assoc()) {

  $camp_name=explode('^',$row['camp_name'])[1];
  $camp_shed_time=$row['camp_shed_time'];
   
  }

}else{





}




$get_camp_id=explode("^", $get_camp_id)[1];

}else{
  $get_camp_id="new campigns";
}


?>


<head>


<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968021/font-owsome/all_nyeyid.css">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">



</head>




<style type="text/css">

.head-of-txt-info{
text-transform: uppercase;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif;
text-align: center;

}


body{


font-family: 'IBM Plex Sans', sans-serif;

}

.vert-cent-div {
	width: min-content;
	height: min-content;
	text-align: center;
	
	position: absolute;
	top:0;
	bottom: 0;
	left: 0;
	right: 0;
  	
	margin: auto;
}

.info-err-img{
	height: 200px;
}

.dt-knw-abt-camp{
	font-weight: 600;
	font-size: 13px;
	padding-top: 10px;
	text-align: center;
}

.txt-hlght-in-para{
	color: green;
}



button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



</style>


<body>


<div class='vert-cent-div'>

	<h2 class='head-of-txt-info'>Campign Is Already Sheduled</h2>

<img class='info-err-img' src='https://res.cloudinary.com/heptera/image/upload/v1603875550/campign/undraw_schedule_pnbk_tu5p4j.svg' >


<p class='dt-knw-abt-camp'>Campign <span class='txt-hlght-in-para'><?php echo $camp_name;?> </span>is Already Sheduled At Time <span class='txt-hlght-in-para'><?php echo $camp_shed_time;?></span>.</p>


<button class='btn_hover_clr'><i class="fal fa-long-arrow-alt-left" style='padding-right:10px;'></i>Back To DashBoard</button>


</div>



</body>
