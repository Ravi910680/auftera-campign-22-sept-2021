


<?php
session_start();
function random_strings($length_of_string) {
     
    // md5 the timestamps and returns substring
    // of specified length
    return substr(md5(time()), 0, $length_of_string);
}
require('./lib_auftera.php');

if(isset($_SESSION['cnt_ab'])){

	$_SESSION['cnt_ab']+=1;

}else{

$_SESSION['cnt_ab']=0;

}


$cnt_ab=$_SESSION['cnt_ab'];


$id=$_SESSION['id'];





$temp_id=$_GET['temp_id'];
$email=$_SESSION['email'];
$sub_field=$_GET['sub_test'];

$send_arr_body=array (
  'to-name' => 'ravi',
  'from' => 'ravigorasiya65@gmail.com',
  'from-name' => 'heptera',
  'subject' => $sub_field,
  'content' => $temp_id,
  'tp_dir' => 'direct',
 
);

$eml_test_id=random_strings(6);


 auft_req_api('POST','send/497889959^dXNlcl9saXN0/template/test-'.$eml_test_id.'@test.mailgenius.com/',$send_arr_body,'f402he2g0gh1j0jl3idih04g');





//get the html returned from the following url
#$html = file_get_contents('https://app.mailgenius.com/spam-test/'.$id); 
//init DOMDocument\
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}


function strip_tags_content($string) { 
    // ----- remove HTML TAGs ----- 
    $string = preg_replace ('/<[^>]*>/', ' ', $string); 
    // ----- remove control characters ----- 
    $string = str_replace("\r", '', $string);
    $string = str_replace("\n", ' ', $string);
    $string = str_replace("\t", ' ', $string);
    // ----- remove multiple spaces ----- 
    $string = trim(preg_replace('/ {2,}/', ' ', $string));
    return $string; 

}


$i=0;




function init_ab_test_get_data($email_id){



$url_tst_rep= 'https://app.mailgenius.com/spam-test/'.$email_id;


$html = file_get_contents($url_tst_rep);
//init DOMDocument\








  $res_arr=array();


$array_of_id=array('1','6','7','9','10','11');




if(!empty($html)){


$start='data-inbound_email_audit_json="';
$end='"';


$str_enc=get_string_between($html, $start, $end);


$jsn_data=json_decode(str_replace("&quot;",'"',$str_enc));








if($jsn_data->mailTesterProps->status=='NOT_READY'){

	sleep($i);

init_ab_test_get_data($email_id);

$i+=1;

}else{

$res_arr['score']=$jsn_data->mailTesterProps->score;



$all_aspc_cnt=0;

foreach ($array_of_id as $key => $value) {


$asp_data=$jsn_data->mailTesterProps->aspects[$value];


$nam_fld=$asp_data->id;

$res_arr['aspect_of'][$all_aspc_cnt]['name']=$nam_fld;
$res_arr['aspect_of'][$all_aspc_cnt]['passed_val']=$asp_data->passing;
$res_arr['aspect_of'][$all_aspc_cnt]['status']=$asp_data->status;
$res_arr['aspect_of'][$all_aspc_cnt]['message']=$asp_data->message;

$all_fact=$asp_data->factors;

$fact_id=0;

foreach ($all_fact as $key_2 => $value_2) {

$fact_data=$value_2;



        $res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['id']=$fact_data->id;
        $res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['title']=$fact_data->title;
        $res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['passed_val']=$fact_data->passing;
        $res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['solution']=$fact_data->solution;
        $res_arr['aspect_of'][$all_aspc_cnt]['factor']['data'][$fact_id]['desc']=$fact_data->passing_description;


$fact_id+=1;



}


$all_aspc_cnt+=1;

}







$str_data=json_encode($res_arr);


print_r(strip_tags_content($str_data));

return 0;


}



}else{

	init_ab_test_get_data($email_id);
}


}

init_ab_test_get_data($eml_test_id);

 
?>
