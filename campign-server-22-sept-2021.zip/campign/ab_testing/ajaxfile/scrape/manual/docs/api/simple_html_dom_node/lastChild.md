# lastChild

```php
lastChild ( ) : object
```

This is a wrapper for [`last_child`](../last_child/).